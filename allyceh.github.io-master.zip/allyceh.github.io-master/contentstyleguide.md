---
# Do NOT Edit layout
layout: default

#Page info: 
title: Content style guide
---

# This is the content style guide

This is a test for placeholder content
